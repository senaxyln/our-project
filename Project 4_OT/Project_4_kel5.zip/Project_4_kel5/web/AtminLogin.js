$(document).ready(function() {
  // Validate sign in form
  $("form").validate({
    rules: {
      AdminID:{
        required: true,
        minlength:6,
        maxlegth:6
      },
      password: {
        required: true,
        minlength: 3
      }
    },
    messages: {
      AdminID: {
        required: "Please enter your email",
        AdminID: "Invalid ID format"
      },
      password: {
        required: "Please enter your password",
        minlength: "Password must be at least 3characters"
      }
    },
    submitHandler: function(form) {
      // Form is valid, submit it
      form.submit();
    }
  });

  // Add event listener to remember me checkbox
  $("#remember-me").on("change", function() {
    if ($(this).is(":checked")) {
      // Remember me is checked, set cookie
      $.cookie("remember_me", "true", { expires: 30 }); // expires in 30 days
    } else {
      // Remember me is not checked, remove cookie
      $.cookie("remember_me", null);
    }
  });

  // Check if remember me cookie is set
  if ($.cookie("remember_me") === "true") {
    // Remember me is set, auto-fill email and password
    $("#email").val("your_email@example.com"); // replace with default email
    $("#password").val("your_password"); // replace with default password
  }
});