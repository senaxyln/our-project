// Ambil elemen tombol hamburger dan menu navbar
const hamburgerBtn = document.querySelector(".hamburger-btn");
const navbar = document.querySelector(".navbar-id");

// Tambahkan event listener untuk klik pada tombol hamburger
hamburgerBtn.addEventListener("click", function () {
  // Toggle kelas 'active' pada menu navbar
  navbar.classList.toggle("active");
});
