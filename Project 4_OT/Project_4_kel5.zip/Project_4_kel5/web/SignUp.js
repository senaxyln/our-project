$(document).ready(function() {
  // Validate sign up form
  $("form").validate({
    rules: {
      nama: {
        required: true,
        minlength: 3
      },
      email: {
        required: true,
        email: true
      },
      password: {
        required: true,
        minlength: 8
      },
      konfirmasi_password: {
        required: true,
        equalTo: "#password"
      }
    },
    messages: {
      nama: {
        required: "Please enter your full name",
        minlength: "Full name must be at least 3 characters"
      },
      email: {
        required: "Please enter your email",
        email: "Invalid email format, example name@gmail.com"
      },
      password: {
        required: "Please enter your password",
        minlength: "Password must be at least 8 characters"
      },
      konfirmasi_password: {
        required: "Please confirm your password",
        equalTo: "Passwords do not match"
      }
    },
    submitHandler: function(form) {
      // Form is valid, submit it
      form.submit();
    }
  });
});