$(document).ready(function() {
  // Validate sign up form
  $("form").validate({
    rules: {
      nama: {
        required: true,
        minlength: 3
      },
      email: {
        required: true,
        email: true
      }
    },
    messages: {
      nama: {
        required: "Please enter your full name",
        minlength: "Full name must be at least 3 characters"
      },
      email: {
        required: "Please enter your email",
        email: "Invalid email format, example name@gmail.com"
      }
    },
    submitHandler: function(form) {
      // Form is valid, submit it
      form.submit();
    }
  });
});