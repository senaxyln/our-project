$(document).ready(function () {
  const concertDetails = {
      "Ariana Grande": { date: "2024-07-01", venue: "GBK Stadium" },
      "Justin Bieber": { date: "2024-07-11", venue: "Ancol Beach" },
      "The 1975": { date: "2024-07-30", venue: "Ancol Beach" },
      "Bryson Tiller": { date: "2024-08-29", venue: "Ancol Beach" },
      "Frank Sinatra": { date: "2024-09-12", venue: "Jakarta International Stadium" },
      "GreenDay": { date: "2024-11-03", venue: "Istora Senayan" },
      "Kendrick Lamar": { date: "2024-11-25", venue: "Jakarta International Stadium" },
      "The Neighbourhood": { date: "2024-12-20", venue: "GBK Stadium" },
      "NIKI": { date: "2024-12-01", venue: "The Kasablanka Hall" },
      "Nirvana": { date: "2025-01-05", venue: "Istora Senayan" },
      "Rihanna": { date: "2025-01-10", venue: "The Kasablanka Hall" }
  };

  const ticketPrices = {
      "Diamond": 12000000,
      "Ruby": 7500000,
      "Gold": 5000000,
      "Silver": 3000000
  };

  $("#artist").change(function () {
      const selectedArtist = $(this).val();
      if (selectedArtist) {
          const details = concertDetails[selectedArtist];
          $("#concert-date").val(details.date);
          $("#concert-venue").val(details.venue);
      } else {
          $("#concert-date").val("");
          $("#concert-venue").val("");
      }
  });

  $("#ticket-type").change(function () {
      const selectedTicketType = $(this).val();
      if (selectedTicketType) {
          const price = ticketPrices[selectedTicketType];
          $("#ticket-price").html(`<option value="${price}">${price}</option>`);
          calculateTotalPrice();
      } else {
          $("#ticket-price").html("");
          $("#total-price").val("");
      }
  });

  $("#num-tickets").on("input", function () {
      calculateTotalPrice();
  });

  function calculateTotalPrice() {
      const ticketPrice = parseFloat($("#ticket-price").val());
      const numTickets = parseInt($("#num-tickets").val());
      if (!isNaN(ticketPrice) && !isNaN(numTickets)) {
          const totalPrice = ticketPrice * numTickets;
          $("#total-price").val(totalPrice);
      } else {
          $("#total-price").val("");
      }
  }

  $('#bookingForm').validate({
      rules: {
          nama: "required",
          telepon: {
            required: true,
            digits: true
          },
          email: {
              required: true,
              email: true
          },
          ktp: {
            required: true,
            digits: true,
            minlength: 16,
            maxlength: 16,
            number: true
          },
          "ticket-type": "required",
          artist: "required",
          "ticket-price": "required",
          "num-tickets": {
              required: true,
              min: 1
          }
      },
      messages: {
          nama: "Nama lengkap harus diisi.",
          telepon: "Nomor telepon harus diisi.",
          email: "Email harus diisi. Example name@gmail.com.",
          ktp: "Nomor KTP harus diisi.",
          "ticket-type": "Jenis tiket harus dipilih.",
          artist: "Artis harus dipilih.",
          "ticket-price": "Harga tiket harus dipilih.",
          "num-tickets": "Jumlah tiket harus minimal 1."
      },
      submitHandler: function (form, event) {
        event.preventDefault(); // Menambahkan ini untuk menghentikan perilaku default form
        const orderDate = new Date().toLocaleDateString(); // Get current date
        $('#receipt-nama').text($('#nama').val());
        $('#receipt-telepon').text($('#telepon').val());
        $('#receipt-email').text($('#email').val());
        $('#receipt-ktp').text($('#ktp').val());
        $('#receipt-ticket-type').text($('#ticket-type').val());
        $('#receipt-venue').text($('#concert-venue').val());
        $('#receipt-artist').text($('#artist').val());
        $('#receipt-ticket-price').text($('#ticket-price option:selected').text());
        $('#receipt-num-tickets').text($('#num-tickets').val());
        $('#receipt-total-price').text($('#total-price').val());
        $('#receipt-order-date').text(`Order Date: ${orderDate}`);
        $('#receipt').show();
      }
  });
});

