import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/TicketManagementServlet")
public class TicketManagementServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String action = request.getParameter("action");

        if ("add".equals(action)) {
            try {
                handleAddTicket(request, response);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(TicketManagementServlet.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else if ("delete".equals(action)) {
            try {
                handleDeleteTicket(request, response);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(TicketManagementServlet.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else if ("update".equals(action)) {
            try {
                handleUpdateTicket(request, response);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(TicketManagementServlet.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        // Fetch ticket data from the database
        fetchTicketData(request, response);

        // Forward to JSP
        request.getRequestDispatcher("AtminPage.jsp").forward(request, response);
    }

    private void handleAddTicket(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException, ClassNotFoundException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        String artis = request.getParameter("nama");
        String tglKonser = request.getParameter("tanggal_konser");
        String tmptKonser = request.getParameter("lokasi_konser");
        String varTiket = request.getParameter("jenis_tiket");
        String harga = request.getParameter("harga_tiket");

        // Generate unique ticket ID
        String ticketID = UUID.randomUUID().toString();

        try 
            (Connection connection = DatabaseConnection.getConnection()) {
            String sql = "INSERT INTO ticket_data (ticketID, artis, tgl_konser, tmpt_konser, var_tiket, harga) VALUES (?, ?, ?, ?, ?, ?)";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, ticketID);
                statement.setString(2, artis);
                statement.setString(3, tglKonser);
                statement.setString(4, tmptKonser);
                statement.setString(5, varTiket);
                statement.setString(6, harga);

                int rowsInserted = statement.executeUpdate();
                if (rowsInserted > 0) {
                    request.setAttribute("successMessage", "A new concert was inserted successfully!");
                }
            }
        } catch (SQLException e) {
            request.setAttribute("errorMessage", "Error: " + e.getMessage());
        }
    }

    private void handleDeleteTicket(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException, ClassNotFoundException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        String ticketID = request.getParameter("ticketID");

        try (Connection connection = DatabaseConnection.getConnection()) {
            String sql = "DELETE FROM ticket_data WHERE ticketID = ?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, ticketID);

                int rowsDeleted = statement.executeUpdate();
                if (rowsDeleted > 0) {
                    request.setAttribute("successMessage", "The concert was deleted successfully!");
                } else {
                    request.setAttribute("errorMessage", "No concert found with the given ID.");
                }
            }
        } catch (SQLException e) {
            request.setAttribute("errorMessage", "Error: " + e.getMessage());
        }
    }

        private void handleUpdateTicket(HttpServletRequest request, HttpServletResponse response) 
                throws ServletException, IOException, ClassNotFoundException {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String ticketID = request.getParameter("ticketID2");
            String artis = request.getParameter("nama2");
            String tglKonser = request.getParameter("tanggal_konser2");
            String tmptKonser = request.getParameter("lokasi_konser2");
            String varTiket = request.getParameter("jenis_tiket2");
            String harga = request.getParameter("harga_tiket2");
            
            System.out.println("Updating ticket with ID: " + ticketID);

            // Check if ticketID is not null or empty
            if (ticketID == null || ticketID.isEmpty()) {
                request.setAttribute("errorMessage", "Ticket ID is required.");
                return;
            }

            try (Connection connection = DatabaseConnection.getConnection()) {
                String sql = "UPDATE ticket_data SET artis = ?, tgl_konser = ?, tmpt_konser = ?, var_tiket = ?, harga = ? WHERE ticketID = ?";
                PreparedStatement statement = connection.prepareStatement(sql);
                statement.setString(1, artis);
                statement.setString(2, tglKonser);
                statement.setString(3, tmptKonser);
                statement.setString(4, varTiket);
                statement.setString(5, harga);
                statement.setString(6, ticketID); // Set ticketID

                int rowsUpdated = statement.executeUpdate();
                if (rowsUpdated > 0) {
                    request.setAttribute("successMessage", "Ticket updated successfully.");
                } else {
                    request.setAttribute("errorMessage", "No ticket found with the given ID.");
                }
            } catch (SQLException e) {
                request.setAttribute("errorMessage", "Error updating ticket: " + e.getMessage());
            }
        }

        private void fetchTicketData(HttpServletRequest request, HttpServletResponse response) 
                throws ServletException, IOException {
            List<Map<String, Object>> ticketData = new ArrayList<>();
            String query = "SELECT * FROM ticket_data";
            try (Connection connection = DatabaseConnection.getConnection();
                 PreparedStatement statement = connection.prepareStatement(query);
                 ResultSet resultSet = statement.executeQuery()) {

                while (resultSet.next()) {
                    Map<String, Object> row = new HashMap<>();
                    row.put("ticketID", resultSet.getString("ticketID"));
                    row.put("artis", resultSet.getString("artis"));
                    row.put("tgl_konser", resultSet.getDate("tgl_konser"));
                    row.put("tmpt_konser", resultSet.getString("tmpt_konser"));
                    row.put("var_tiket", resultSet.getString("var_tiket"));
                    row.put("harga", resultSet.getBigDecimal("harga"));
                    ticketData.add(row);
                }
                request.setAttribute("ticketData", ticketData); // Set ticketData in request
            } catch (SQLException e) {
                request.setAttribute("errorMessage", "Error fetching ticket data.");
            }
        }


}
