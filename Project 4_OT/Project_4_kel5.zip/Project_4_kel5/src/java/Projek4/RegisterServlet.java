import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String nama = request.getParameter("nama");
        String email = request.getParameter("email");
        String tanggalLahir = request.getParameter("Tanggal_lahir");
        String gender = request.getParameter("gender");
        String password = request.getParameter("password");
        String konfirmasiPassword = request.getParameter("konfirmasi-password");

        if (!password.equals(konfirmasiPassword)) {
            request.setAttribute("errorMessage", "Password and Confirm Password do not match.");
            request.getRequestDispatcher("SignUp.jsp").forward(request, response);
            return;
        }

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            // Establish connection using DatabaseConnection class
            Connection conn = DatabaseConnection.getConnection();

            // Check if email already exists
            String checkEmailSql = "SELECT email FROM user_data WHERE email = ?";
            PreparedStatement checkStmt = conn.prepareStatement(checkEmailSql);
            checkStmt.setString(1, email);
            ResultSet rs = checkStmt.executeQuery();
            
            if (rs.next()) {
                // Email already exists
                request.setAttribute("errorMessage", "Email sudah ada.");
                request.getRequestDispatcher("SignUp.jsp").forward(request, response);
                return;
            }
            
            // Prepare SQL statement
            String sql = "INSERT INTO user_data (nama, email, Tanggal_lahir, gender, password) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, nama);
            stmt.setString(2, email);
            stmt.setString(3, tanggalLahir);
            stmt.setString(4, gender);
            stmt.setString(5, password);

            // Execute SQL statement
            int rowsInserted = stmt.executeUpdate();
            if (rowsInserted > 0) {
                request.setAttribute("successMessage", "A new user was inserted successfully!");
                request.getRequestDispatcher("SignUp.jsp").forward(request, response);
            }

            // Close connection
            rs.close();
            checkStmt.close();
            stmt.close();
            conn.close();

        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Error occurred: " + e.getMessage());
            request.getRequestDispatcher("SignUp.jsp").forward(request, response);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(RegisterServlet.class.getName()).log(Level.SEVERE, null, ex);
            request.setAttribute("errorMessage", "Error occurred: " + ex.getMessage());
            request.getRequestDispatcher("SignUp.jsp").forward(request, response);
        }
    }
}
